This is how to compile my code:
1. first join or go onto the OSU OS servers for Oregon State university.
2. Then navigate into the directory where you have unziped the file and go into the file.
3. Then type into terminal "gcc -std=c99 main.c -o main -pthread" and hit enter.
4. Finally, type ./main and click enter.
5. then the program should run, follow the prompt as the program entends.